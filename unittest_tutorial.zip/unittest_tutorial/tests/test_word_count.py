import unittest

from src.word_count import remove_string_punctuation
from src.word_count import count_words_in_string
from src.word_count import count_all_words_in_string
from src.word_count import count_all_words_in_list_of_strings

class TestWordCountMethods(unittest.TestCase):

    def test_remove_string_punctuation(self):
        word = remove_string_punctuation('//}{//he...l-"l,,,::;o')
        self.assertEqual(word, 'hello')
        word = remove_string_punctuation('-')
        self.assertEqual(word, '')

    def test_count_words_in_string(self):
        amount = count_words_in_string('hello world', 'hello')
        self.assertEqual(amount, 1)

    def test_if_count_word_is_case_sensitive(self):
        amount = count_words_in_string('Hello World', 'hello')
        self.assertEqual(amount, 1)
        amount = count_words_in_string('hello world', 'Hello')
        self.assertEqual(amount, 1)

    def test_check_if_word_count_ignore_punctuation(self):
        amount = count_words_in_string('Hello, World!', 'hello')
        self.assertEqual(amount, 1)
        amount = count_words_in_string('Hel, lo World!', 'hello')
        self.assertEqual(amount, 0)

    def test_count_all_words_in_string(self):
        words_dict = count_all_words_in_string('Hello World! \n - Friendly hello: hello...')
        self.assertEqual(words_dict, {'hello': 3, 'world': 1, 'friendly': 1})
        words_dict = count_all_words_in_string('Hello Friendly hello')
        self.assertEqual(words_dict, {'hello': 2, 'friendly': 1})

    def test_count_all_words_in_list_of_strings(self):
        words_dict = count_all_words_in_list_of_strings(['Hello World!', '- Friendly hello.', 'Hello....'])
        self.assertEqual(words_dict, {'hello': 3, 'world': 1, 'friendly': 1})

if __name__ == '__main__':
    unittest.main()