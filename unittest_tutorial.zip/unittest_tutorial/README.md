# Tutorial on Unit Testing with Python 

<div align="center">
![software teting with python](images/software_test.jpg)
</div>

## Introduction

This tutorial was made to introduce **Test Driven Development** to the U9 Machine Learning team. It will explain the main concepts that can be implemented in the process of design and coding projects, as how to do it in Python. 

You certainly already test your code with `print()`, but doing so makes it more difficult to assess whether one test succeeds or fails among several other tests. So this causes you to remove already written tests just because it's not the unit you're currently focusing on. Everyone here probably write several print statements, checks if it's  all as expected, and then erases the "tests" to let the code cleaner. To deal with these problems, we're going to use a package that helps us automate and write tests for out code, but we also need to learn to code with the tests in mind.

**What you will learn following this tutorial:**
1. What is Unit Test and Test Driven Developmente (TDD);
2. How to design tests to your code;
3. How to use the `unittest` package for unit test in Python;

There is two main packages to do unit test in Python:
* unittest (built in python base)
* pytest

This tutorial will show how to do unit testing using the `unittest` Python package (also know as PyUnit), but this do not mean that it's the best or the mostly widely use package to this purpose. ~~Later I will do a similar tutorial on the `pytest` package.~~

## Test Driven Development

<div align="center">
![TDD diagram](images/what-is-tdd.png)
</div>

First, we need to introduce what is the main idea behind the Test Driven Development (TDD): 

>**You write your tests first, watch them fail, and then you write the code that makes your tests work.**

Why? The *testing first* aproach is forces you to plan your code better based on the tests you have writen, making it cleaner and easier to understand. The tests will make you to plan the steps (functions/taks) before everything else and make you focus on what matters the most. It's a nice guide to follow because it tends to make you write the minimum amount of code needed to build your project.

An important point to add is that dosen't mean your code will be perfect all the time. Refactoring your code is part of any developer's job and, even if your code is well tested and has no problems, it still can be nonoptimal. The idea behind refactoring code is to make it better without changes in functionality, and that why refactor is bestly done when you have well tested code. The tests writen for your nonoptimal code should work in the same way with the newer code, because the *unit* being tested has the same *function* (if you are doing refactor properly).

Besides making your code more reliable, TDD grants your code will have at least some documentation of what you are writing. When approaching new code, it's easier to understand what each part does if you read the tests first, because you have the expected outputs for each unit. This concept works because you are forced to write modularized code (an idea I'm personally trying to push to our team's code) instead of a giant python script with some comments as documentation and no descriptive functions names.

## Unit Test

<div align="center">
![unittest logo](images/pyunit-logo.png)
</div>

### What is Unit Test:

Wikipedia: 
> *"Method by which individual units of source code—sets of one or more computer program modules together with associated control data, usage procedures, and operating procedures—are tested to determine whether they are fit for use."*

By now, you probably already understood what unit testing means. But how is this done in practice? Haha, not o fast padawan... First I will tell you how to design unit tests.

### How to design unit tests:

Now you are probably asking: "How do I write a test in Python???". The answer for that question will come soon, because now you need to know how to design your tests. There is some simple rules to follow when creating a unit test:

1. A Unit Test will test (*durr*) some part of you code; 
2. Tests need to be independent of each other;
3. Each test needs to run fast enough so you can run every test constantly;
4. A test will follow the **GIVEN-WHEN-THEN** structure (it's useful to write it sometimes);
5. A test should evaluate not only the regular behaviour but also the edge cases;
6. Unit Test should test logic, flow control and configuration (do not test *contants*);

### How to write unit test with `unittest`:

Finally we are here. To write a unit test you first need to create a python file containing your test. The `unittest` package have some standards you need to follow, but several things are configurable, and the editor you are using can help with it (VSCode is "helpful" at least...). We are going to use VSCode to do this demonstration, so I'll show how I learned to do things in it. The test file and the test functions need to start with the `test_` keyword.

`file: test_file_with_unit_code.py`
``` 
import unittest
from file_with_unit_code import unit_you_want_to_test

class TestNameOfTheModuleYouWantToTest(unittest.TestCase):

    def test_name_of_the_unit_you_want_to_test(self): # never forget to add the self for methods
        
        # GIVEN
        var1 = 1
        var2 = 2

        # WHEN
        result = unit_you_want_to_test(var1, var2)

        # THEN
        self.assertEqual(result, 3)
```

Probably you neet to tweek some things in your project folder to make it work properly, but when it start working, the VSCode will help you to run the tests. It's also useful to add the main mathod in the end of your file.

```
if __name__ == '__main__':
    unittest.main()
```

This is the most basic way to write your test. **You probably should try it now.**

### Edge Cases

One of the greatest things to do using tests is to make sure your code can handle inputs that are different of what you expected. Check the example bellow:

```
def count_words(input_string: str, search_word: str) -> int:
    list_of_words = input_string.split()
    return list_words_without_punctuation.count(search_word)
```

This functions is simple: it creates a list with all the words in the input string (words are separated by a space character) and count how many times the search word appears in the list. If you run `count_words('this is a test test test', 'test')`, the result should be 3 because the word 'test' appears 3 times in the input string. But what happens when you run the code `count_words('This is a test. Test. Test', 'test')`? The result is now zero. This is because the variable `list_of_words` will be the list `['This', 'is', 'a', 'test.', 'Test.', 'Test']` and the value `'test'` does not appear at all on the list. 

Creating a test capable of checking this kind of extreme case allows us to do a better function, one that deals with upper and lower case letters and with punctuations. Knowing this, let's write code to test the `count_words` function that not only calls one assert statement but several others with the edge cases we want to cover.

```
from count_words_module import count_words

class TestCoutWordsModule(unittest.TestCase):
    def test_count_words(self):
        self.assertEqual(count_words('first test', 'test'), 1)
        self.assertEqual(count_words('Test? No test.', 'test'), 2)
        self.assertEqual(count_words('I'm trying my best!', 'test'), 0)
        self.assertEqual(count_words('', 'test'), 0)
```

### Asserts

There are several assert methods you can use to test your code. Some of the most important ones are in the following table:

| Method                     | Checks            |
|----------------------------|-------------------|
| *assertEqual(a, b)*       | `a == b`          |
| *asserGreater(a, b)*       | `a > b`           |
| *assertGreaterEqual(a, b)* | `a >= b`          |
| *assertTrue(x)*            | `bool(x) is True` |
| *assertIs(a, b)*           | `a is b`          |
| *assertIsNone(x)*          | `x is None`       |
| *assertIn(a, b)*           | `a in b`          |
| *assertIsInstance(a, b)*   | `isinstance(a, b` |
| *assertRegex(s, r)*        | `r.search(s)`     |
| *assertRaises(exc, fun, \*args, \*\*kwds)*         | `fun(*args, **kwds)` raises *exc* |
| *assertRaisesRegex(exc, r, fun, \*args, \*\*kwds)* | `fun(*args, **kwds)` raises *exc* and the message matches regex *r* |
| *assertCountEqual(a, b)*                        | *a* and *b* have the same elements in the same number, regardless of their order |

Probably you will user just a small sample of these, but it's important to know you have a choice at least~.

### Skipping tests and expected failures

Let's say you wrote a test before the function, as intended by TDD, and now you notice a problem with another function you wrote earlier. You want to solve all the problems of this old function, but don't want to erase the tests you just wrote for the new one. The problem is that the newer test is always failing because its function is not yet finished. The solution for this situations is to use a decorator to skip the newer test, or if necessary, you can use a decorator to assert that the test will fail. See the example bellow:

```
class TestModuleName(unittest.TestCase):

    @unittest.skip("message")
    def test_function_skipped(self):
        self.assertEqual(function_skipped(0), 1)

    @unittest.skipIf(condition == is_present(), "message")
    def test_function_maybe_skipped(self):
        self.assertEqual(function_maybe_skipped(0), 1)

    @unittest.expectedFailure
    def test_function_needs2fail(self):
        self.assertEqual(function_needs2fail(), "fail")
```

The message in the `@unittest.skip("message")` is a text will be shown in the terminal when the test is skipped together with the message saying the test is being skiped. If you don't want to see a message like this, you can use `@unittest.expectedFailure` decorator, but for this case, it's necessary that the assert expression fails to the test be succesfull.

### The methods setUp() and tearDown()

These methods are very straightfoward: `setUp(self)` will run before of all tests, and `tearDown(self)` will be run after. They will come in handy when it's necessary to do some preparition before starting the tests. An example usage is to launch Chrome (chromedriver) when working with `Selenium` and close it at the end. But remember, if code inside the `setUp` fails, the test will fail and the test method will not be executed. The `tearDown` will happen regardless of wether the test succeed or fails (but the setUp needs to succeed).

`Example_setUp_tearDown.py`
```
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

class TestSeleniumModule(unittest.TestCase):
    def setUp(self):
        chrome_options = Options()
        chrome_options.add_argument('no-sandbox')
        self.driver = webdriver.Chrome(options=chrome_options)

    def tearDown(self):
        self.driver.quit()

    def test_scraping(self):
        link = 'https://www.google.com.br/
        self.driver.get(link)
        self.assertEqual(self.driver.title, 'Google')
```

## References
1. [Harry J. W. Pecival's book "*Test-Driven Development with Python, Django, Selenium and JavaScripts*" (2017) - O'Reilly Media.](https://www.amazon.com.br/Test-Driven-Development-Python-Selenium-JavaScript-ebook/dp/B074HXXXLS/ref=sr_1_1?__mk_pt_BR=%C3%85M%C3%85%C5%BD%C3%95%C3%91&dchild=1&keywords=teste+driven+development+with+python+django&qid=1635271336&sr=8-1&ufe=app_do%3Aamzn1.fos.25548f35-0de7-44b3-b28e-0f56f3f96147)
2. [unittest library Documentation](https://docs.python.org/3/library/unittest.html)
3. [Corey Schafer Tutorial on the unittest module (YouTube)](https://youtu.be/6tNS--WetLI)