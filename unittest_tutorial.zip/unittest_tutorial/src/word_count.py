import string
from collections import Counter

def remove_string_punctuation(input_string: str) -> str:
    """
    Return the input_string removing all the punctuations on it.
    Input: 
        input_string: A string;
    Output: String without punctuation [str]
    """
    return input_string.translate(str.maketrans('', '', string.punctuation))

def count_words_in_string(input_string: str, search_word: str) -> int:
    """
    Return the amount of time the input word appears in the input string.
    Input:
        input_string: A string;
        search_word: The word you want to count in the string;
    Output: Count of word [int];
    """

    list_of_words = input_string.split()
    list_words_lower_case = [x.lower() for x in list_of_words]
    list_words_without_punctuation = [remove_string_punctuation(x) for x in list_words_lower_case]
    return list_words_without_punctuation.count(search_word.lower())

def count_all_words_in_string(input_string: str) -> dict:
    """
    Return a dictionary with a key for every word in the input string. The value in each key is the amount of time the world appears in the string.
    Input:
        input_string: A string;
    Output: Count of words [dict];
    """
    words_in_string = input_string.split()
    list_words_lower_case = [x.lower() for x in words_in_string]
    words_without_punctuation = [remove_string_punctuation(x) for x in list_words_lower_case]
    try:
        words_without_punctuation.remove('')
    except:
        pass
    words_dict = {}
    for word in words_without_punctuation:
        words_dict[word] = count_words_in_string(input_string, word)
    return words_dict

def count_all_words_in_list_of_strings(input_list: list) -> dict:
    """
    Return a dictionary with a key for every word in the input list of strings. The value in each key is the amount of time the world appears in all the strings.
    Input:
        input_string: A list;
    Output: Count of words [dict];
    """
    list_of_dicts = [count_all_words_in_string(x) for x in input_list]
    list_of_counters = [Counter(x) for x in list_of_dicts]
    return dict(sum(list_of_counters, Counter()))

input_list = ['Hello World!', '- Friendly hello.', 'Hello....']